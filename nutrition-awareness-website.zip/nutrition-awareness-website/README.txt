NUTRITION AWARENESS WEBSITE

1. Extract this ZIP file.
2. Open index.html in Chrome, Safari, Edge or Firefox.
3. Keep the assets folder beside index.html so the project photos load.

The website is responsive and includes smooth scrolling navigation, project sections based on the uploaded report, and the uploaded project images.
